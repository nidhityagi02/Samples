/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.mailinator;

import com.chargepoint.qa.base.CPPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by Nidhi on 12-05-2015.
 */
public class MailinatorInboxPage extends CPPage {

    final WebDriver driver;

    @FindBy(how= How.ID,using = "inboxfield")
    private WebElement INBOX ;

    @FindBy(how= How.XPATH,using = "//div[contains(text(), '@chargepoint.com')]")
    private WebElement EMAIL ;

    @FindBy(how= How.XPATH,using = "//div[contains(text(), 'New Admin Account Created:')]")
    private WebElement NEW_ACCOUNT_CREATED_EMAIL ;





    public MailinatorInboxPage(WebDriver dr){
        this.driver = dr;
    }


public void verifyEmailPresent(){

        if (isElementPresent(driver,EMAIL)){
            EMAIL.click();
        }


}

    public void createChargePointAccount(){

        verifyEmailPresent();


    }



    public void verifyNewAdminAccountCreated(){
        if (isElementPresent(driver,NEW_ACCOUNT_CREATED_EMAIL)) {
            System.out.print("Account Created");
        }
    }
}

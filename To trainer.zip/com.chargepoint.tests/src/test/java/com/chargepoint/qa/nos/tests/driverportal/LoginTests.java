package com.chargepoint.qa.nos.tests.driverportal;

import com.chargepoint.qa.base.CPTest;
import com.chargepoint.qa.nos.pageobjects.driverportal.LoginPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.*;

import java.util.HashMap;
import java.util.Iterator;

/**
 * Created by Nidhi on 4/12/15.
 */
public class LoginTests extends CPTest {
    LoginPage loginPage;

    final static Logger logger = Logger.getLogger(LoginTests.class);

    @BeforeTest
    public void setup() throws Exception {
        loginPage = PageFactory.initElements(driver, LoginPage.class);
        loginPage.setWebDriverWait(wait);
    }

    /*
    * Note this entire method is reusable. It will read a csv and return results in a
    * hashmap array.
     */
    @DataProvider(name = "loginlist")
    public Iterator<Object[]> readCSV(ITestContext context ) throws Exception {
        //A parameter called local-config-file must be defined in testng.xml
        String testParam = context.getCurrentXmlTest().getParameter("local-config-file");
        ClassLoader classLoader = getClass().getClassLoader();
        return commonTestHelper.processCSVtoHashMap(classLoader.getResource(testParam).getFile());
    }


    @AfterMethod
    public void logout() {
        loginPage.logout();
    }

    @Test(dataProvider = "loginlist")
    public void loginTest(HashMap<String, String> csvRec) {
        logger.info("Executing tests with "+csvRec.get("LoginName"));
        if (Boolean.valueOf(csvRec.get("ExpectedResult"))) {
            Assert.assertTrue(loginPage.loginByUserPassword(csvRec.get("LoginName"), csvRec.get("LoginPassword")));
        }else{
            Assert.assertTrue(loginPage.loginByUserPasswordFails(csvRec.get("LoginName"), csvRec.get("LoginPassword")));
        }

    }
}

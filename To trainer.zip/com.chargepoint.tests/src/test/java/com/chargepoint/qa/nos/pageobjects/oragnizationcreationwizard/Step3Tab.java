/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.oragnizationcreationwizard;

import com.chargepoint.qa.base.CPPage;
import com.chargepoint.qa.nos.tests.datacreationflow.DataCreationFlow;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by Nidhi on 13-05-2015.
 */
public class Step3Tab extends CPPage {

    final WebDriver driver;

    @FindBy(how = How.CSS, using = "input[value='Continue to Step 4 >>']")
    public WebElement CONTINUE_TO_NEXT_STEP;


    @FindBy(how= How.ID,using = "state")
    private WebElement STATE ;
    public Step3Tab(WebDriver dr){
        this.driver = dr;
    }



    public void NavigatetoNextSteps(){
   try {
       select(driver, STATE, DataCreationFlow.datacreationProp.getProperty("STATE"));
       Thread.sleep(2000);
       CONTINUE_TO_NEXT_STEP.click();
       Thread.sleep(2000);
   }
   catch(Exception e){
       captureScreenshot(driver,"Step3");
       e.printStackTrace();
   }

    }


}

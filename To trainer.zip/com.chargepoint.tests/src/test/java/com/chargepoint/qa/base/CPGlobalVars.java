package com.chargepoint.qa.base;

/**
 * Created by abhiputhenveetil on 4/30/15.
 */
public class CPGlobalVars {

    public static final String CONF_BROWSER = CPTest.prop.getProperty("CONF_BROWSER");
    public static final int CONF_WAIT_TIME = Integer.valueOf(CPTest.prop.getProperty("CONF_WAIT_TIME"));
    public static final String CONF_HOSTNAME = CPTest.prop.getProperty("CONF_HOSTNAME");
    public static final String CONF_HOSTNAME_MAILINATOR = CPTest.prop.getProperty("CONF_HOSTNAME_MAILINATOR");

}

package com.chargepoint.qa.utils;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

/**
 * Created by Nidhi on 4/30/15.
 */
public class JavaScriptRunner {
    /*
    *Simple function makes an async GET call, and returns with results as a string.
     */
    public String runAsyncGetCall(WebDriver dr, String jsBody) {


        JavascriptExecutor js;
        String jnk = "var callback = arguments[arguments.length - 1];" +
                "var xhr = new XMLHttpRequest();" +
                "xhr.open('GET', '" + jsBody + "', false);" +
                "xhr.onreadystatechange = function() {" +
                "  if (xhr.readyState == 4) {" +
                "    callback(xhr.responseText);" +
                "  }" +
                "};" +
                "xhr.send();";


        Object retObj = ((JavascriptExecutor) dr).executeAsyncScript(jnk);
        return (String) retObj;
    }
}

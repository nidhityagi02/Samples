package com.chargepoint.qa.nos.pageobjects.driverportal;

import com.chargepoint.qa.base.CPGlobalVars;
import com.chargepoint.qa.base.CPPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Properties;
import java.util.concurrent.TimeUnit;

/**
 * Created by nidhi on 4/14/15.
 */
public class LoginPage extends CPPage {
    final WebDriver driver;

    @FindBy(how = How.ID, using = "user_name")
    public WebElement txtbx_userName;

    @FindBy(how = How.ID, using = "user_password")
    public WebElement txtbx_userPassword;

    @FindBy(how = How.ID, using = "validate-login")
    public WebElement btn_submitButton;

    @FindBy(how = How.CLASS_NAME, using = "user")
    public WebElement str_welcome;

    @FindBy(how = How.ID, using = "login_error_message")
    public WebElement str_failedlogin;

    public LoginPage(WebDriver dr){

        this.driver = dr;
    }


    /**
     *
     * @param username
     * @param userpassword

     * @return returns false is login fails
     */
    public boolean loginByUserPassword(String username, String userpassword ){
        driver.navigate().to("https://" + CPGlobalVars.CONF_HOSTNAME + "/home");
        txtbx_userName.sendKeys(username);
        txtbx_userPassword.sendKeys(userpassword);
        btn_submitButton.click();
        //driver.manage().timeouts().implicitlyWait(CPGlobalVars.CONF_WAIT_TIME, TimeUnit.SECONDS);
        //driver.manage().timeouts().w

        try{
            wait.until(ExpectedConditions.visibilityOf(str_welcome));
            //WebElement welcome = driver.findElement(By.className("welcome"));
            return (str_welcome.getText().equals("Welcome,"));
        }catch(org.openqa.selenium.NoSuchElementException e){
            //Did not see Welcome means login failed.
            return false;
        }
    }

    /**
    * Returns true if login fails. Desirable than wasting time waiting for next page to NOT appear.
     */
    public boolean loginByUserPasswordFails(String username, String userpassword ){
        driver.navigate().to("https://"+CPGlobalVars.CONF_HOSTNAME+"/home");

        txtbx_userName.sendKeys(username);
        txtbx_userPassword.sendKeys(userpassword);
        btn_submitButton.click();
       // WebDriverWait wait = new WebDriverWait(driver, CPGlobalVars.CONF_WAIT_TIME);
        try {
            wait.until(ExpectedConditions.visibilityOf(str_failedlogin));
        }catch(Exception e){
            //Did not see warning message appear
            return false;
        }
        return true;


    }


    public void logout(){
        driver.navigate().to("https://"+CPGlobalVars.CONF_HOSTNAME+"/logout");
        driver.manage().timeouts().implicitlyWait(CPGlobalVars.CONF_WAIT_TIME, TimeUnit.SECONDS);
    }

}

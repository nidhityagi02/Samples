/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.mailinator;

import com.chargepoint.qa.base.CPPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by rsehgal on 13-05-2015.
 */
public class MailinatorContentPage  extends CPPage {

    final WebDriver driver;

    @FindBy(how= How.XPATH,using = "//a[contains(@href,'cpnos.ev-chargepoint.com/welcome/invite')]")
    private WebElement CREATE_ACCOUNT_LINK ;



    public MailinatorContentPage(WebDriver dr){
        this.driver = dr;
    }


    public void ClickAccountLinkPresent() {

//        if (isElementPresent(driver,CREATE_ACCOUNT_LINK)){
        try {
           Thread.sleep(6000);
            driver.switchTo().frame("rendermail");
            CREATE_ACCOUNT_LINK.click();
        } catch (Exception e) {
            captureScreenshot(driver,"Account_link");
            e.printStackTrace();
        }

//        }
    }




}

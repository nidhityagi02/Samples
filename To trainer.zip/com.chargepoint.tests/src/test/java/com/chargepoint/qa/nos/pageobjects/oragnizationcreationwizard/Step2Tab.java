/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.oragnizationcreationwizard;

import com.chargepoint.qa.base.CPPage;

import com.chargepoint.qa.base.CPTest;
import com.chargepoint.qa.nos.tests.datacreationflow.DataCreationFlow;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by Nidhi on 13-05-2015.
 */
public class Step2Tab extends CPPage {

    final WebDriver driver;

    @FindBy(how= How.ID,using = "user_add1")
    private WebElement ADDRESS ;

    @FindBy(how= How.ID,using = "country")
    private WebElement COUNTRY ;

    @FindBy(how= How.ID,using = "state")
    private WebElement STATE ;

    @FindBy(how= How.ID,using = "user_city")
    private WebElement CITY ;

    @FindBy(how= How.ID,using = "user_zip")
    private WebElement POSTAL_CODE ;

    @FindBy(how= How.ID,using = "user_phone")
    private WebElement PHONE ;


    @FindBy(how = How.CSS, using = "input[value='Continue to Step 3 >>']")
    public WebElement CONTINUE_TO_NEXT_STEP;



    public Step2Tab(WebDriver dr){
        this.driver = dr;
    }


    public void enterStep2details()  {
        try {
            waitForElementtoPresent(driver,ADDRESS,Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));

            ADDRESS.sendKeys(DataCreationFlow.datacreationProp.getProperty("ADDRESS"));
            select(driver, COUNTRY, DataCreationFlow.datacreationProp.getProperty("COUNTRY"));
            Thread.sleep(2000);
            select(driver, STATE, DataCreationFlow.datacreationProp.getProperty("STATE"));
            CITY.sendKeys(DataCreationFlow.datacreationProp.getProperty("CITY"));
            POSTAL_CODE.sendKeys(DataCreationFlow.datacreationProp.getProperty("POSTAL_CODE"));
            PHONE.sendKeys(DataCreationFlow.datacreationProp.getProperty("PHONE"));
            Thread.sleep(2000);
            CONTINUE_TO_NEXT_STEP.click();
            Thread.sleep(2000);
        }catch(Exception e)
        {
            captureScreenshot(driver,"Step2");
            e.printStackTrace();
        }
    }
}

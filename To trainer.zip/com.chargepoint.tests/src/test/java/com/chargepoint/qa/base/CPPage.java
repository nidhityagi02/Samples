package com.chargepoint.qa.base;


import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.io.File;
import java.util.Date;
import java.util.NoSuchElementException;
import java.util.Properties;

/**
 * Created by Raghu on 4/21/2015.
 */
public class CPPage {

    public final static Logger LOGGER = Logger.getLogger(CPPage.class);
    protected WebDriverWait wait;
    private static int uniquifySequence;
    public static final String working_dir = System.getProperty("user.dir");
    static{
        DOMConfigurator.configure("src/test/resources/log4j.properties");
        LOGGER.info("Logs Inititated");
    }

    public void setWebDriverWait(WebDriverWait wt){
        this.wait=wt;
    }


    public void clickWhenReady(WebElement webElement) throws Exception {
        if (wait == null){
            Assert.fail("Please initialize wait variable");
            throw(new Exception("Uninitialized wait variable"));
        }
        try{
            LOGGER.debug("Wait & Click on Element - " + webElement.getText());
            wait.until(ExpectedConditions.elementToBeClickable(webElement));
            webElement.click();
        }
         catch(NotFoundException e){
             LOGGER.debug("Element not found Exception on  - " + webElement.getText());
             e.printStackTrace();
             throw (e);
         }catch(Exception e){
            LOGGER.error("General Exception");
            e.printStackTrace();
            throw (e);

        }
    }


/**
 * Need to work on this function, this can be called to take screenshot when any error occurs
 *
  */

/*
    public static void takeScreenshot(String fileName) {
        File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(scrFile, new File("screenshots\\"+fileName));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
*/

public void waitForElementtoPresent(WebDriver driver,final WebElement element,int timeOutInSeconds){
    WebDriverWait wait = new WebDriverWait(driver, timeOutInSeconds);

    wait.until(new ExpectedCondition<Boolean>() {


        public Boolean apply(WebDriver d) {
            return element.isDisplayed();
        }
    });

}

    public void verifyElementPresent(WebDriver driver,WebElement element){
        try {
            LOGGER.debug("verifying element present - " + element.getText());
            waitForElementtoPresent(driver,element,Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));

        }catch (Exception e) {
            LOGGER.error("Element not present - " + element.getText());
            throw new NoSuchElementException(element+"Element is not found");
        }

    }
    public Boolean isElementPresent(WebDriver driver,WebElement element) {
        try {
            LOGGER.debug("verifying element present - " + element.getText());
            waitForElementtoPresent(driver,element, 40);
            return true;
        } catch (Exception e) {
            LOGGER.error("Element not present - " + element.getText());
            return false;
        }
    }
    public String uniquify(String prefix) {
        StringBuilder key = new StringBuilder();

        if (StringUtils.isNotEmpty(prefix))
            key.append(prefix);

        // add a counter to the milli timestamp, in case a bunch of keys are generated at once
//        long currentMillis = new Date().getTime();
//        currentMillis += (++uniquifySequence);
        key.append(RandomStringUtils.randomAlphabetic(5).toLowerCase());

        return key.toString();
    }
    public void select(WebDriver driver,WebElement selectElement, String typedInput) {

        try {
            if (isElementPresent(driver,selectElement)) {

                new Select(selectElement).selectByVisibleText(typedInput);

            }
        } catch (Exception e) {
            LOGGER.error("Element not present - " + selectElement.getText());
            throw new NoSuchElementException(selectElement + "Element is not found");
        }
    }


    public void captureScreenshot(WebDriver driver, String filename) {
        try {
            File Scrnsht = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(Scrnsht, new File(working_dir + "\\" + filename + ".png"));
        } catch (Exception e) {
            LOGGER.info("Not able to take snapshot");
        }
    }

}

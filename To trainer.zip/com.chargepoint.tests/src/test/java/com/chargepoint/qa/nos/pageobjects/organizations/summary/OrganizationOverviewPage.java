/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.organizations.summary;

import com.chargepoint.qa.base.CPPage;
import com.chargepoint.qa.base.CPTest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

/**
 * Created by Nidhi on 28-04-2015.
 */
public class OrganizationOverviewPage extends CPPage {

    final WebDriver driver;

    @FindBy(how = How.CSS, using = "#action_columns_right>a.new")
    private   WebElement CREATE_ORGANIZATION;

    @FindBy(how = How.CSS, using = "div[id='table_content']>table>tbody>tr:nth-child(1)>td>pre>a")
    private   WebElement ORG_NAME_TABLE;

    @FindBy(how = How.CSS, using = "#flexbillingTab")
    private   WebElement FLEX_BILLING_TAB;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'Flex Billing Status')]/following-sibling::span")
    private   WebElement FLEX_BILLING_STATUS;

    @FindBy(how = How.XPATH, using = "//label[contains(text(),'kWh Billing')]/following-sibling::span")
    private   WebElement KWH_BILLING;

    @FindBy(how = How.CSS, using = "#filterTab")
    private   WebElement FILTER_TAB;

    @FindBy(how = How.CSS, using = ".filterTextInput")
    private   WebElement FILTER_INPUT;

    @FindBy(how = How.CSS, using = ".applybutton")
    private   WebElement APPLY_FILTER;

    @FindBy(how = How.CSS, using = "input[value='Approve']")
    private   WebElement APPROVE;



    public  OrganizationOverviewPage(WebDriver dr) {

        this.driver = dr;

}

public void clickCreateOrganization()  {


try {
    verifyCreateOrganizationlink();
    CREATE_ORGANIZATION.click();
    throw new IndexOutOfBoundsException();
}catch (Exception e){
captureScreenshot(driver,"Create_Org");
}


}

    public void verifyCreateOrganizationlink(){

        waitForElementtoPresent(driver, CREATE_ORGANIZATION, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));


    }


    public void Create_Filter(String OrgName){
        try {
        FILTER_TAB.click();
            waitForElementtoPresent(driver, FILTER_INPUT, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));

            FILTER_INPUT.sendKeys(OrgName);

            Thread.sleep(3000);
            APPLY_FILTER.click();
            Thread.sleep(6000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void Click_Org_Name_Link(){
        waitForElementtoPresent(driver, ORG_NAME_TABLE, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));

        ORG_NAME_TABLE.click();
    }


    public void Click_Flex_Billing_Tab(){
        FLEX_BILLING_TAB.click();

    }

    public void Click_Approve(){
        waitForElementtoPresent(driver, APPROVE, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));

        APPROVE.click();

    }
    public void Verify_Flex_Fields(){
        Assert.assertEquals(FLEX_BILLING_STATUS.getText(),"Not Enabled");
        Assert.assertEquals(KWH_BILLING.getText(),"Not Enabled");
    }


}

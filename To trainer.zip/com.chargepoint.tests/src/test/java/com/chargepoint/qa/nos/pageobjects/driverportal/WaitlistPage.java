package com.chargepoint.qa.nos.pageobjects.driverportal;

import com.chargepoint.qa.base.CPPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.concurrent.TimeUnit;


/**
 * Created by Nidhi on 5/1/15.
 */
public class WaitlistPage extends CPPage {

    final static Logger logger = Logger.getLogger(WaitlistPage.class);

    final WebDriver driver;

    @FindBy(how = How.ID, using = "i_chargespots")
    public WebElement btn_ChargeSpots;

    @FindBy(how = How.ID, using = "i_community")
    public WebElement btn_WaitList;

    @FindBy(how = How.ID, using = "join_waitlist_button_has_saved_waitlists")
    public WebElement btn_createWaitList_existing;

    @FindBy(how = How.ID, using = "search_field")
    public WebElement txtxbox_search;

    @FindBy(how = How.ID, using = "userRegionName")
    public WebElement txtbox_regionName;

    @FindBy(how = How.ID, using = "community_region_save")
    public WebElement btn_waitlist_save;

    @FindBy(how = How.XPATH, using = "/html/body/div[7]/div[3]/div/button")
    public WebElement btn_ok;

    @FindBy(how = How.ID, using = "searchButton")
    public WebElement btn_address_search;

    @FindBy(how = How.XPATH, using = "//*[@id=\"join_has_saved_waitlists\"]/div[3]/ul/li[5]/div[1]/div[1]")
    public WebElement btn_edit_waitlist;

    @FindBy(how = How.ID, using = "community_region_delete")
    public WebElement btn_delete_waitlist;

    @FindBy(how = How.XPATH, using = "/html/body/div[4]/div[3]/div/button[1]")
    public WebElement btn_confirm_delete;

    @FindBy(how = How.ID, using = "autoshedule_edit_link")
    public WebElement link_autoschedule;

    @FindBy(how = How.ID, using = "autoschedule_from_time")
    public WebElement select_fromTime;

    @FindBy(how = How.ID, using = "autoshedule_until_time")
    public WebElement select_toTime;

    @FindBy(how = How.ID, using = "autoschedule-m")
    public WebElement chkbox_Monday;

    @FindBy(how = How.ID, using = "autoschedule_save")
    public WebElement btn_autoscheduleSave;

    @FindBy(how = How.ID, using = "autoScheduleOnButt")
    public WebElement btn_autoscheduleOn;

    @FindBy(how = How.ID, using = "autoScheduleOffButt")
    public WebElement btn_autoscheduleOff;

    @FindBy(how = How.ID, using = "removeMeButt")
    public WebElement btn_removeMe;

    @FindBy(how = How.XPATH, using = "/html/body/div[7]/div[3]/div/button[2]")
    public WebElement btn_yes;

    public WaitlistPage(WebDriver driver) {
        this.driver = driver;
    }




    public boolean createWaitList(String address, String waitListName) {
        logger.info("Entering createWaitlist...");
        try {
            clickWhenReady(btn_createWaitList_existing);
            logger.info("Address for WaitList - " + address);
            this.txtxbox_search.sendKeys(address);
            this.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            this.btn_address_search.click();
            Thread.sleep(1000);

            clickWhenReady(btn_WaitList);
            clickWhenReady(btn_createWaitList_existing);
            logger.info("WaitList Name - " + waitListName);
            this.txtbox_regionName.sendKeys(waitListName);
            clickWhenReady(btn_waitlist_save);
            clickWhenReady(btn_ok);
            Thread.sleep(2000);

        } catch (Exception e) {
            return false;
        }
        return true;
    }


    public boolean removeFromWaitList() {
        try {
            clickWhenReady(btn_WaitList);

            clickWhenReady(btn_removeMe);
            clickWhenReady(btn_yes);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean enableAutoSchedule(String waitListName, String from, String to) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(btn_createWaitList_existing));

            List<WebElement> regions = this.driver.findElements(By.className("waitlist_list_item"));

            for (WebElement option : regions) {
                WebElement regionname = option.findElement(By.className("waitlist_item_top"));
                if ((waitListName).equalsIgnoreCase(regionname.getText())) {
                    WebElement editbutton = option.findElement(By.id("pendingEditButton"));
                    clickWhenReady(editbutton );
                    clickWhenReady(link_autoschedule);
                    btn_autoscheduleOn.click();
                    Select fromTime = new Select(select_fromTime);
                    fromTime.selectByVisibleText(from);
                    Select toTime = new Select(select_toTime);
                    toTime.selectByVisibleText(to);
                    boolean chkvalue = chkbox_Monday.isSelected();
                    if (!chkvalue) {
                        chkbox_Monday.click();
                    }
                    btn_autoscheduleSave.click();
                    clickWhenReady(btn_waitlist_save);
                    try {
                        Thread.sleep(2000);
                    } catch (Exception e) {
                    }

                }
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public boolean deleteWaitList(String waitListName) {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(btn_createWaitList_existing));
            List<WebElement> regions = this.driver.findElements(By.className("waitlist_list_item"));

            for (WebElement option : regions) {
                WebElement regionname = option.findElement(By.className("waitlist_item_top"));
                if ((waitListName).equalsIgnoreCase(regionname.getText())) {
                    WebElement editButton = option.findElement(By.id("pendingEditButton"));
                    clickWhenReady(editButton);
                    clickWhenReady(btn_delete_waitlist);
                    //This needs to be fixed. Unable to locate the element - Need to find an alternate solution.
                    clickWhenReady(btn_confirm_delete);
                }
            }
        } catch (Exception e) {
            return false;
        }
        return true;
    }




}

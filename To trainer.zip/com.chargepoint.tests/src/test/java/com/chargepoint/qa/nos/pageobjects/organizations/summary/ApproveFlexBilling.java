/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.organizations.summary;

import com.chargepoint.qa.base.CPPage;
import com.chargepoint.qa.base.CPTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by Nidhi on 27-05-2015.
 */
public class ApproveFlexBilling extends CPPage {

    final WebDriver driver;

    @FindBy(how = How.CSS, using = "#flexbillingContainerDialog")
    private WebElement FLEX_BILLING_CONTAINER;

    @FindBy(how = How.CSS, using = "#flexBilling")
    private WebElement FLEX_BILLING_CHKBOX;


    @FindBy(how = How.CSS, using = "#hasKwh")
    private WebElement KWH_BILLING;


    @FindBy(how = How.CSS, using = "#vendorId")
    private WebElement REMITTANCE_ID;

    @FindBy(how = How.CSS, using = "#noc_submit")
    private WebElement SUBMIT;
    @FindBy(how = How.CSS, using = "div[aria-labelledby='ui-dialog-title-warn_currency']")
    private WebElement CURRENCY_POPUP;

    @FindBy(how = How.CSS, using = "div[aria-labelledby='ui-dialog-title-warn_currency']>div:nth-child(3)>div>button:nth-child(2)")
    private WebElement OK_BUTTON;


    @FindBy(how = How.CSS, using = "div[aria-labelledby='ui-dialog-title-alert']>div:nth-child(3)>div>button")
    private WebElement ALERT_OK_BUTTON;

    public ApproveFlexBilling(WebDriver dr) {

        this.driver = dr;

    }


    public void Approve_Flex_Billing() {
try {
    waitForElementtoPresent(driver,FLEX_BILLING_CONTAINER,Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
    FLEX_BILLING_CHKBOX.click();
    REMITTANCE_ID.sendKeys("TestingID");
    SUBMIT.click();
    waitForElementtoPresent(driver, CURRENCY_POPUP, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));


    OK_BUTTON.click();
    Thread.sleep(3000);
    ALERT_OK_BUTTON.click();

}
catch (Exception e){
    e.printStackTrace();
}
}
}

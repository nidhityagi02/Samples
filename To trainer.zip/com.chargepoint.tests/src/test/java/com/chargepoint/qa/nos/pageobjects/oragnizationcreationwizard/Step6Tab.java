/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.oragnizationcreationwizard;

import com.chargepoint.qa.base.CPPage;
import com.chargepoint.qa.base.CPTest;
import com.chargepoint.qa.nos.tests.datacreationflow.DataCreationFlow;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.security.Credentials;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by Nidhi on 13-05-2015.
 */
public class Step6Tab  extends CPPage {

    final WebDriver driver;


    @FindBy(how = How.ID, using = "txtlegalname")
    private WebElement ORG_LEGAL_NAME;

    @FindBy(how = How.ID, using = "txtlegaladdress")
    private WebElement LEGAL_ADD_1;

    @FindBy(how = How.ID, using = "txtlegaladdress2")
    private WebElement LEGAL_ADD_2;

    @FindBy(how = How.ID, using = "step6_country_org")
    private WebElement COUNTRY;

    @FindBy(how = How.ID, using = "step6_state_org")
    private WebElement STATE;

    @FindBy(how = How.NAME, using = "txtcity")
    private WebElement CITY;

    @FindBy(how = How.NAME, using = "txtzip")
    private WebElement POSTAL_CODE;

    @FindBy(how = How.NAME, using = "txtfederalname")
    private WebElement TAX_ID;

//    ===========================================PAYMENT INFORMATION

    @FindBy(how = How.NAME, using = "currency")
    private WebElement REMITTANCE_CURRENCY;

    @FindBy(how = How.NAME, using = "txtcontactname")
    private WebElement ACCOUNT_RECEIVABLE_CONTACT_NAME;

    @FindBy(how = How.NAME, using = "txtemailcontact")
    private WebElement ACCOUNT_RECEIVABLE_CONTACT_EMAIL;

    @FindBy(how = How.NAME, using = "txtcontactphone")
    private WebElement ACCOUNT_RECEIVABLE_CONTACT_PHONE;



    //    ===========================================ACH INFORMATION

    @FindBy(how = How.NAME, using = "txtbankname")
    private WebElement BANK_NAME;

    @FindBy(how = How.NAME, using = "bankaddressline1")
    private WebElement BANK_ADRESSLINE1;


    @FindBy(how = How.NAME, using = "bankaddressline2")
    private WebElement BANK_ADRESSLINE2;

    @FindBy(how = How.NAME, using = "bank_country_org")
    private WebElement BANK_COUNTRY;

    @FindBy(how = How.NAME, using = "bank_state_org")
    private WebElement BANK_STATE;


    @FindBy(how = How.NAME, using = "bank_city")
    private WebElement BANK_CITY;
    @FindBy(how = How.NAME, using = "bank_zip")
    private WebElement BANK_POSTAL_CODE;

    @FindBy(how = How.NAME, using = "txtbankroutingnumber")
    private WebElement ABA_ROUTING_NO;

    @FindBy(how = How.NAME, using = "txtaccountnumber")
    private WebElement BANK_ACCOUNT_NO;


    @FindBy(how = How.NAME, using = "txtsignature")
    private WebElement ENTER_YOUR_INITIAL;

    @FindBy(how = How.NAME, using = "txtprint")
    private WebElement PRINT_NAME;

    @FindBy(how = How.NAME, using = "txttitle")
    private WebElement TITLE;

    @FindBy(how = How.ID, using = "createOrg")
    private WebElement CREATE_ORG;

    @FindBy(how = How.CSS, using = "div[aria-labelledby='ui-dialog-title-warn_currency']")
    private WebElement CURRENCY_POPUP;

    @FindBy(how = How.CSS, using = "div[aria-labelledby='ui-dialog-title-warn_currency']>div:nth-child(3)>div>button:nth-child(2)")
    private WebElement OK_BUTTON;


    public Step6Tab(WebDriver dr){
        this.driver = dr;
    }



    public void Create_ORG()  {
        try {
         Thread.sleep(1000);
            ORG_LEGAL_NAME.sendKeys(uniquify("Legal"));
            LEGAL_ADD_1.sendKeys(DataCreationFlow.datacreationProp.getProperty("LEGAL_ADD_1"));
            LEGAL_ADD_2.sendKeys(DataCreationFlow.datacreationProp.getProperty("LEGAL_ADD_2"));
            select(driver, COUNTRY, DataCreationFlow.datacreationProp.getProperty("COUNTRY"));
            Thread.sleep(2000);
            select(driver, STATE, DataCreationFlow.datacreationProp.getProperty("STATE"));
            CITY.sendKeys(DataCreationFlow.datacreationProp.getProperty("CITY"));
            POSTAL_CODE.sendKeys(DataCreationFlow.datacreationProp.getProperty("POSTAL_CODE"));
            TAX_ID.sendKeys(DataCreationFlow.datacreationProp.getProperty("TAX_ID"));
            select(driver, REMITTANCE_CURRENCY, DataCreationFlow.datacreationProp.getProperty("REMITTANCE_CURRENCY"));
            ACCOUNT_RECEIVABLE_CONTACT_NAME.sendKeys(uniquify("Name"));
            ACCOUNT_RECEIVABLE_CONTACT_EMAIL.sendKeys(uniquify("E") + "@mailinator.com");
            ACCOUNT_RECEIVABLE_CONTACT_PHONE.sendKeys(DataCreationFlow.datacreationProp.getProperty("ACCOUNT_RECEIVABLE_CONTACT_PHONE"));
            BANK_NAME.sendKeys(DataCreationFlow.datacreationProp.getProperty("BANK_NAME"));
            BANK_ADRESSLINE1.sendKeys(DataCreationFlow.datacreationProp.getProperty("BANK_ADRESSLINE1"));
            BANK_ADRESSLINE2.sendKeys(DataCreationFlow.datacreationProp.getProperty("BANK_ADRESSLINE2"));
            select(driver, BANK_COUNTRY, DataCreationFlow.datacreationProp.getProperty("BANK_COUNTRY"));
            Thread.sleep(2000);
            select(driver, BANK_STATE, DataCreationFlow.datacreationProp.getProperty("BANK_STATE"));
            BANK_CITY.sendKeys(DataCreationFlow.datacreationProp.getProperty("BANK_CITY"));
            BANK_POSTAL_CODE.sendKeys(DataCreationFlow.datacreationProp.getProperty("BANK_POSTAL_CODE"));
            ABA_ROUTING_NO.sendKeys(DataCreationFlow.datacreationProp.getProperty("ABA_ROUTING_NO"));

            BANK_ACCOUNT_NO.sendKeys(DataCreationFlow.datacreationProp.getProperty("BANK_ACCOUNT_NO"));
            ENTER_YOUR_INITIAL.sendKeys(DataCreationFlow.datacreationProp.getProperty("ENTER_YOUR_INITIAL"));
            PRINT_NAME.sendKeys(DataCreationFlow.datacreationProp.getProperty("PRINT_NAME"));
            TITLE.sendKeys(DataCreationFlow.datacreationProp.getProperty("TITLE"));

            CREATE_ORG.click();

            waitForElementtoPresent(driver, CURRENCY_POPUP, 30);
            OK_BUTTON.click();

            Thread.sleep(40000);
        }
        catch (Exception e){
            captureScreenshot(driver,"Step6");
            e.printStackTrace();
        }
    }








}

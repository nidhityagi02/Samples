package com.chargepoint.qa.nos.pageobjects.organizations.summary;

import com.chargepoint.qa.base.CPPage;
import com.chargepoint.qa.base.CPTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

/**
 * Created by Nidhi on 28-04-2015.
 */
public class NewOrgPage extends CPPage {

     String  email ;
    String orgName ;


    final WebDriver driver;


    @FindBy(how= How.CSS,using = ".moduleheaderclean>p")
    private WebElement NEW_ORG_LABEL ;

    @FindBy(how= How.ID,using = "organization_name")
    private WebElement ORG ;

    @FindBy(how= How.ID,using = "stationNameLine2")
    private WebElement STATION_COMMON_NAME ;

    @FindBy(how= How.ID,using = "yourcustomer_type")
    private WebElement CUSTOMER_TYPE_MY_CUSTOMER ;

    @FindBy(how= How.ID,using = "coulombcustomer_type")
    private WebElement CUSTOMER_TYPE_MY_COULOMB ;

    @FindBy(how= How.ID,using = "customer_demo_yes")
    private WebElement DEMO_YES ;

    @FindBy(how= How.ID,using = "customer_demo_no")
    private WebElement DEMO_NO ;


    @FindBy(how= How.NAME,using = "first_name")
    private WebElement FIRST_NAME ;

    @FindBy(how= How.NAME,using = "last_name")
    private WebElement LAST_NAME ;

    @FindBy(how= How.NAME,using = "email")
    private WebElement EMAIL ;

    @FindBy(how= How.ID,using = "newOrgSubmitBtn")
    private WebElement CREATE ;

    @FindBy(how= How.CSS,using = ".moduleheaderclean>p")
    private WebElement ORG_CREATED;

    public  NewOrgPage(WebDriver dr) {

        this.driver = dr;

    }

    public void  Create_New_Organization()  {
        this.email = uniquify("E");
        this.orgName =uniquify("ORG");
        System.out.print(email+orgName);
        try {
            ORG.sendKeys(orgName);
            STATION_COMMON_NAME.sendKeys(uniquify("SC"));
            FIRST_NAME.sendKeys(uniquify("FIRSTN"));
            LAST_NAME.sendKeys(uniquify("LASTN"));

            EMAIL.sendKeys(email+ "@mailinator.com");
            CREATE.click();
            Thread.sleep(5000);
            Assert.assertEquals(ORG_CREATED.getText(),"Organization created and invitation sent");

        }
        catch(Exception e){
            captureScreenshot(driver,"Create_New_Org");
            e.printStackTrace();

        }

    }


    public String getEmail(){

        return this.email;
    }

    public String getOrgname(){

        return this.orgName;
    }


    public void verifyFields(){

        verifyElementPresent(driver,ORG);
        verifyElementPresent(driver,STATION_COMMON_NAME);
        verifyElementPresent(driver,CUSTOMER_TYPE_MY_CUSTOMER);
        verifyElementPresent(driver,CUSTOMER_TYPE_MY_COULOMB);
        verifyElementPresent(driver,DEMO_NO);
        verifyElementPresent(driver,DEMO_YES);
        verifyElementPresent(driver,FIRST_NAME);
        verifyElementPresent(driver,LAST_NAME);
        verifyElementPresent(driver,EMAIL);
    }


}

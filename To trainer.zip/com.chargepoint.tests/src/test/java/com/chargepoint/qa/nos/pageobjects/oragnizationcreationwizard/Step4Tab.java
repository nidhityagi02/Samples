/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.oragnizationcreationwizard;

import com.chargepoint.qa.base.CPPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by Nidhi on 13-05-2015.
 */
public class Step4Tab extends CPPage {

    final WebDriver driver;

    @FindBy(how = How.ID, using = "select_billing")
    public WebElement FLEX_BILLING;

    @FindBy(how = How.ID, using = "select_service")
    public WebElement SERVICE_SUPPORT;

    @FindBy(how = How.ID, using = "select_sys_admin")
    public WebElement SYSTEM_ADMIN;

    @FindBy(how = How.ID, using = "select_new_station_req")
    public WebElement NEW_STATIONREQUESTS;

    @FindBy(how = How.ID, using = "select_admin_notice")
    public WebElement ADMINISTRATIVE_NOTICES;

    @FindBy(how = How.ID, using = "select_subscription_renewal")
    public WebElement SERVICE_PLAN_RENEWALS;

    @FindBy(how = How.ID, using = "select_new_system_features")
    public WebElement NEW_SYSTEM_FEATURES;

    @FindBy(how = How.ID, using = "select_driver_feedback")
    public WebElement DRIVER_FEEDBACK;

    @FindBy(how = How.ID, using = "select_maintenance_feedback")
    public WebElement MAINTAINENACE_FEEDBACK;

    @FindBy(how = How.CSS, using = "input[value='Continue to Step 5 >>']")
    private WebElement CONTINUE_TO_NEXT_STEP;

    public Step4Tab(WebDriver dr){
        this.driver = dr;
    }


    public void Select_Whom_To_Contacts(){
try {
    Thread.sleep(2000);
    select(driver, FLEX_BILLING, "Me");

    select(driver, SERVICE_SUPPORT, "Me");

    select(driver, SYSTEM_ADMIN, "Me");

    select(driver, NEW_STATIONREQUESTS, "Me");

    select(driver, ADMINISTRATIVE_NOTICES, "Me");

    select(driver, SERVICE_PLAN_RENEWALS, "Me");

    select(driver, NEW_SYSTEM_FEATURES, "Me");

    select(driver, DRIVER_FEEDBACK, "Me");

    select(driver, MAINTAINENACE_FEEDBACK, "Me");

    CONTINUE_TO_NEXT_STEP.click();
    Thread.sleep(2000);
}
catch (Exception e){
    captureScreenshot(driver,"Step4");
    e.printStackTrace();
}










    }



}

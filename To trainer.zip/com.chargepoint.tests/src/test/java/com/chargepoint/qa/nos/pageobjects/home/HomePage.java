/**
 * @author rsehgal
 */
package com.chargepoint.qa.nos.pageobjects.home;

import com.chargepoint.qa.base.CPPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

/**
 * Created by Nidhi on 28-04-2015.
 */
public class HomePage extends CPPage {

    final WebDriver driver;

    @FindBy(how= How.CSS,using = "#fixed>div>ul>li:nth-child(10)>a")
    private WebElement ORGANIZATIONS ;

    @FindBy(how= How.CSS,using = "#fixed>div>ul>li:nth-child(4)>a")
    private WebElement MANAGE_STATIONS ;




    public HomePage(WebDriver dr) {
        this.driver = dr;
//        PageFactory.initElements(Driver, this);
    }

    public void clickOrganizationTab()  {


            ORGANIZATIONS.click();

    }

    public void clickManageStationsnTab()  {


        MANAGE_STATIONS.click();

    }





}

package com.chargepoint.qa.base;

import com.chargepoint.qa.utils.CommonTestHelper;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public abstract class CPTest {
    public static CommonTestHelper commonTestHelper;
    public static WebDriver driver;
    public static WebDriverWait wait;
    public static Properties prop;



    @BeforeSuite(alwaysRun=true)
    @Parameters({ "config-file" })
    public void initBeforeSuite(String configfile) {
        commonTestHelper = new CommonTestHelper();

        //Find common.properties and load it.
        prop = new Properties();
        ClassLoader classLoader = getClass().getClassLoader();
        try {


            File file = new File(classLoader.getResource(configfile).getFile());
            FileInputStream conf = new FileInputStream(file);
            prop.load(conf);
            driver = commonTestHelper.getCorrectDriver(prop.getProperty("CONF_BROWSER"));
            driver.manage().timeouts().pageLoadTimeout(Integer.parseInt(prop.getProperty("CONF_WAIT_TIME")), TimeUnit.SECONDS);
            wait = new WebDriverWait(this.driver, Integer.parseInt(prop.getProperty("CONF_WAIT_TIME")));

        }catch  (FileNotFoundException e) {
            e.printStackTrace();
            Assert.fail("Could not open config file. Please make sure config-file is defined intestng.xml");
        } catch (IOException e) {
            e.printStackTrace();
            Assert.fail("Could not open config file. Please make sure config-file is defined intestng.xml");

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Unknown error occured");

        }}




    @AfterSuite(alwaysRun=true)
    public void tearDown(){
        driver.close();
        driver.quit();
    }

}

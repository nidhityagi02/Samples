/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.tests.datacreationflow;

import com.chargepoint.qa.base.CPPage;
import com.chargepoint.qa.base.CPTest;
import com.chargepoint.qa.nos.pageobjects.driverportal.LoginPage;
import com.chargepoint.qa.nos.pageobjects.driverportal.WaitlistPage;
import com.chargepoint.qa.nos.pageobjects.home.HomePage;
import com.chargepoint.qa.nos.pageobjects.mailinator.MailinatorContentPage;
import com.chargepoint.qa.nos.pageobjects.mailinator.MailinatorHomePage;
import com.chargepoint.qa.nos.pageobjects.mailinator.MailinatorInboxPage;
import com.chargepoint.qa.nos.pageobjects.managestations.ManageStation;
import com.chargepoint.qa.nos.pageobjects.oragnizationcreationwizard.*;
import com.chargepoint.qa.nos.pageobjects.organizations.summary.ApproveFlexBilling;
import com.chargepoint.qa.nos.pageobjects.organizations.summary.NewOrgPage;
import com.chargepoint.qa.nos.pageobjects.organizations.summary.OrganizationOverviewPage;
import com.chargepoint.qa.nos.tests.driverportal.WaitlistTests;
import org.apache.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;

import java.util.Properties;

/**
 * Created by Nidhi on 05-05-2015.
 */
public class DataCreationFlow  extends CPTest {

//    NOC_Level_2_admin_should_be_able_to_create_USD_organization

    public static Properties datacreationProp;
    String Email;
    String Network_Manger_username;
    //Pages required for this test
    LoginPage loginPage;
    HomePage homePage;
    OrganizationOverviewPage organizationOverviewPage;
    NewOrgPage newOrgPage;
    MailinatorHomePage mailinatorHomePage;
    MailinatorInboxPage mailinatorInboxPage;
    MailinatorContentPage mailinatorContentPage;
    Step1Tab step1Tab;
    Step2Tab step2Tab;
    Step3Tab step3Tab;
    Step4Tab step4Tab;
    Step5Tab step5Tab;
    Step6Tab step6Tab;
    ApproveFlexBilling approveFlexBilling;
    ManageStation manageStation;
    final static Logger logger = Logger.getLogger(WaitlistTests.class);

    @Parameters({ "waitlist-config-file" })
    @BeforeTest
    public void SetUp(String waitListConfigFile) throws Exception {

        datacreationProp = commonTestHelper.loadPropertiesFile(waitListConfigFile);
        loginPage = PageFactory.initElements(driver, LoginPage.class);
        loginPage.setWebDriverWait(wait);
        homePage = PageFactory.initElements(driver, HomePage.class);
        homePage.setWebDriverWait(wait);
        organizationOverviewPage = PageFactory.initElements(driver, OrganizationOverviewPage.class);
        organizationOverviewPage.setWebDriverWait(wait);
        newOrgPage = PageFactory.initElements(driver, NewOrgPage.class);
        newOrgPage.setWebDriverWait(wait);
        mailinatorHomePage = PageFactory.initElements(driver, MailinatorHomePage.class);
        mailinatorHomePage.setWebDriverWait(wait);
        mailinatorInboxPage = PageFactory.initElements(driver, MailinatorInboxPage.class);
        mailinatorInboxPage.setWebDriverWait(wait);
        mailinatorContentPage= PageFactory.initElements(driver, MailinatorContentPage.class);
        mailinatorContentPage.setWebDriverWait(wait);
        step1Tab = PageFactory.initElements(driver, Step1Tab.class);
        step1Tab.setWebDriverWait(wait);

        step2Tab = PageFactory.initElements(driver, Step2Tab.class);
        step2Tab.setWebDriverWait(wait);

        step3Tab = PageFactory.initElements(driver, Step3Tab.class);
        step3Tab.setWebDriverWait(wait);

        step4Tab = PageFactory.initElements(driver, Step4Tab.class);
        step4Tab.setWebDriverWait(wait);

        step5Tab = PageFactory.initElements(driver, Step5Tab.class);
        step5Tab.setWebDriverWait(wait);

        step6Tab = PageFactory.initElements(driver, Step6Tab.class);
        step6Tab.setWebDriverWait(wait);

        approveFlexBilling = PageFactory.initElements(driver, ApproveFlexBilling.class);
        approveFlexBilling.setWebDriverWait(wait);

        manageStation = PageFactory.initElements(driver, ManageStation.class);
        manageStation.setWebDriverWait(wait);
        loginPage.loginByUserPassword(datacreationProp.getProperty("CONF_USERNAME"), datacreationProp.getProperty("CONF_PASSWORD"));

    }


@Test(priority=1)
public void verifyOrganizationLink(){
    CPPage.LOGGER.debug("Veriying Organization tab - ");
    homePage.clickOrganizationTab();
    organizationOverviewPage.verifyCreateOrganizationlink();
    }
@Test(dependsOnMethods = "verifyOrganizationLink")
    public void verifyNewOrganizationPageFields(){
    CPPage.LOGGER.debug("Veriying new  Organization page fields - ");
    organizationOverviewPage.clickCreateOrganization();
    newOrgPage.verifyFields();
    }
    @Test(dependsOnMethods = "verifyNewOrganizationPageFields")
    public void createNewOrganization(){
        CPPage.LOGGER.debug("Creating new  Organization  - ");
          newOrgPage.Create_New_Organization();


    }
@Test(dependsOnMethods = "createNewOrganization")
public void AccessNetworkManageEmail(){
    CPPage.LOGGER.debug("Opening New tab with email not present - ");
    mailinatorHomePage.open_New_Tab(newOrgPage.getEmail());

    mailinatorInboxPage.createChargePointAccount();
    CPPage.LOGGER.debug("Creating new  Organization  - ");
    mailinatorContentPage.ClickAccountLinkPresent();


}
    @Test(dependsOnMethods = "AccessNetworkManageEmail")
    public void Org_CreationWizard(){
        CPPage.LOGGER.debug("Entering Steps details  - ");
        step1Tab.enterStep1details();
        step2Tab.enterStep2details();
        step3Tab.NavigatetoNextSteps();
        step4Tab.Select_Whom_To_Contacts();
        step5Tab.Agree_Terms();
        step6Tab.Create_ORG();

    }

    @Test(dependsOnMethods = "Org_CreationWizard")
    public void New_Account_Created(){
        CPPage.LOGGER.debug("Creating New Account  - ");
        mailinatorHomePage.open_New_Tab(newOrgPage.getEmail());
        mailinatorInboxPage.verifyNewAdminAccountCreated();
    }

//    @Test(dependsOnMethods = "New_Account_Created")
//    public void Finance_Login(){
//
//        loginPage.loginByUserPassword(datacreationProp.getProperty("FINANCE_USERNAME"), datacreationProp.getProperty("FINANCE_PASSWORD"));
//        homePage.clickOrganizationTab();
//        organizationOverviewPage.Create_Filter(newOrgPage.getOrgname());
//
//        organizationOverviewPage.Click_Org_Name_Link();
//        organizationOverviewPage.Click_Flex_Billing_Tab();
//        organizationOverviewPage.Verify_Flex_Fields();
//        organizationOverviewPage.Click_Approve();
//
//    }
//
//    @Test(dependsOnMethods = "Finance_Login")
//public void Approve_Flex_Billing(){
//approveFlexBilling.Approve_Flex_Billing();
//
//
//}
//    dependsOnMethods = "New_Account_Created"
@Test(dependsOnMethods = "New_Account_Created")
    public void NetworkMangerCreatingPolicy(){
        loginPage.loginByUserPassword(step1Tab.getMangerName(), datacreationProp.getProperty("PASSWORD"));
//        loginPage.loginByUserPassword("wertyu", "wertyu12");

        try {
            homePage.clickManageStationsnTab();
            manageStation.CreatePolicy();
        } catch (InterruptedException e) {

            e.printStackTrace();
        }


    }
    @AfterTest
    public void logout() {
        logger.info("Entering - LogOut");
        //Uncomment the below line once a method is added to verify that the driver has joined waitlist
        loginPage.logout();
    }






}

package com.chargepoint.qa.utils;

import com.csvreader.CsvReader;
import io.github.bonigarcia.wdm.ChromeDriverManager;
import io.github.bonigarcia.wdm.InternetExplorerDriverManager;
import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

/**
 * Created by Nidhi on 4/15/15.
 */
public class CommonTestHelper {

    public enum BrowserType{
        MOZILLA, CHROME, IE
    }

    final static Logger logger = Logger.getLogger(CommonTestHelper.class);


    /*
    * processCSVtoHashMap takes a csvfilename as parameter an iteratir of object arrays(think of it as  an array of hashmaps)
    * Each hashmap contains a row of csv file, which can be referred by using title key.
    * Eg: IF CSV file is of following format
    * FirstName, LastName
    * Abhi, Puth
    * Raghu, Ta
    *
    * The test class simple access the cols as hashmap.get("FirstName") and hash.get("LastName"
     */
    public Iterator<Object[]> processCSVtoHashMap(String csvfilename) throws Exception
    {
        List<Object[]> testCases = new ArrayList<Object[]>();
        CsvReader csvrows = new CsvReader(String.valueOf(csvfilename));
        csvrows.readHeaders();


        while (csvrows.readRecord())
        {
            HashMap<String, String> csvrec = new HashMap<String, String>();
            for (String header : csvrows.getHeaders()){
                csvrec.put(header, csvrows.get(header));
            }
            Object[] retkeyword = {csvrec};
            testCases.add(retkeyword);

        }
        csvrows.close();
        return testCases.iterator();
    }


    /**
     * @param browserType -MOZILLA, IE, CHROME
     * @return Webdriver of the requested type
     * @throws Exception on any param other than MOZILLA, IE, CHROME
     */
    public WebDriver getCorrectDriver(String browserType) throws Exception {
        switch (BrowserType.valueOf(browserType)){
           case MOZILLA:
               logger.info("Browser used - " + browserType);
               FirefoxDriver firefoxDriver =  new FirefoxDriver();
               firefoxDriver.manage().window().maximize();
               return (firefoxDriver);
           case CHROME:
               logger.info("Browser used - " + browserType);
               //System.setProperty("webdriver.chrome.driver", "D://test/chromedriver.exe");
               ChromeDriverManager.setup();
               ChromeDriver chromeDriver = new ChromeDriver();
               chromeDriver.manage().window().maximize();
               return (chromeDriver);
           case IE:
               logger.info("Browser used - " + browserType);
               InternetExplorerDriverManager.setup();
               InternetExplorerDriver iEDriver =  new InternetExplorerDriver();
               iEDriver.manage().window().maximize();
               return (iEDriver);
           default :
               logger.error("Unknown Browser used - " + browserType);
               throw (new Exception("Unknown browser type"));
       }
    }

    /**
     * This is a Generic fucntion used to load any properties file. The input to this function is the filename.
     * @param fileName
     * @return
     */
    public Properties loadPropertiesFile(String fileName) {

        Properties prop = new Properties();
        InputStream input = null;
        try {
            input = getClass().getClassLoader().getResourceAsStream(fileName);
            if (input == null) {
                logger.error("Unable to find - " + fileName);
                return prop;
            }
            prop.load(input);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        return prop;
    }




}

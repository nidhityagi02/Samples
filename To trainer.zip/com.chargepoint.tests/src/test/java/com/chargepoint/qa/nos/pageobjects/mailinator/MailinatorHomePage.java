/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.mailinator;

import com.chargepoint.qa.base.CPGlobalVars;
import com.chargepoint.qa.base.CPPage;

import com.chargepoint.qa.base.CPTest;
import com.chargepoint.qa.nos.pageobjects.driverportal.LoginPage;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by rsehgal on 12-05-2015.
 */
public class MailinatorHomePage extends CPPage {

    final WebDriver driver;
    String parentHandle;
    @FindBy(how= How.ID,using = "inboxfield")
    private WebElement INBOX ;

    @FindBy(how= How.CSS,using = ".btn-success")
    private WebElement CHECK_IT_BUTTON ;



    public  MailinatorHomePage(WebDriver dr) {

        this.driver = dr;

    }
//
//    public void Check_Inbox(String Email){
//
//        INBOX.sendKeys(Email);
//        CHECK_IT_BUTTON.click();
//    }

    public void open_New_Tab(String Email){


        new LoginPage(driver).logout();

         parentHandle = driver.getWindowHandle(); // get the current
        for (String winHandle : driver.getWindowHandles()) { // Gets the new
            driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL, "t"); // open new tab
//            String url = "https://" + CPGlobalVars.CONF_HOSTNAME_MAILINATOR + "/inbox.jsp?to=" + Email;
            String url = "https://" + CPTest.prop.getProperty("CONF_HOSTNAME_MAILINATOR") +"/inbox.jsp?to=" + Email;
            driver.navigate().to(url);

            driver.switchTo().window(winHandle); // switch focus to newly


        }



    }


    public void close_Parrent_tab(){
        driver.switchTo().window(parentHandle);

//        driver.findElement(By.tagName("body")).sendKeys(Keys.CONTROL,"w"); // close new tab

    }



}

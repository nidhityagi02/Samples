package com.chargepoint.qa.nos.tests.driverportal;

import com.chargepoint.qa.base.CPTest;
import com.chargepoint.qa.nos.pageobjects.driverportal.LoginPage;
import com.chargepoint.qa.nos.pageobjects.driverportal.WaitlistPage;
import org.apache.log4j.Logger;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import java.util.Properties;

/**
 * Created by Nidhi on 5/1/15.
 */
public class WaitlistTests extends CPTest {
    Properties waitListProp;

    //Pages required for this test
    LoginPage loginPage;
    WaitlistPage waitlistPage;

    final static Logger logger = Logger.getLogger(WaitlistTests.class);

    @Parameters({ "waitlist-config-file" })
    @BeforeTest
    public void setup(String waitListConfigFile) throws Exception {
        waitListProp = commonTestHelper.loadPropertiesFile(waitListConfigFile);
        loginPage = PageFactory.initElements(driver, LoginPage.class);
        loginPage.setWebDriverWait(wait);
        waitlistPage = PageFactory.initElements(driver, WaitlistPage.class);
        waitlistPage.setWebDriverWait(wait);
        
    }

    @Test(priority = 1)
    public void createAndJoinWaitList(){
        logger.info("Entering - Create & Join WaitList");
        loginPage.loginByUserPassword(waitListProp.getProperty("CONF_USERNAME"), waitListProp.getProperty("CONF_PASSWORD"));
        waitlistPage.createWaitList(waitListProp.getProperty("CONF_ADDRESS"),waitListProp.getProperty("CONF_WAITLIST_NAME"));
    }

    @Test(priority = 2)
    public void quitWaitList(){
        logger.info("Entering - Quit WaitList");
        loginPage.loginByUserPassword(waitListProp.getProperty("CONF_USERNAME"), waitListProp.getProperty("CONF_PASSWORD"));
        waitlistPage.removeFromWaitList();

    }


    @Test(priority = 3, dependsOnMethods = {"quitWaitList"})
    public void enableAutoSchedule() {
        logger.info("Entering - Enable Auto Schedule");
        loginPage.loginByUserPassword(waitListProp.getProperty("CONF_USERNAME"), waitListProp.getProperty("CONF_PASSWORD"));
        waitlistPage.enableAutoSchedule(waitListProp.getProperty("CONF_WAITLIST_NAME"), waitListProp.getProperty("CONF_FROM_TIME"), waitListProp.getProperty("CONF_TO_TIME"));
    }

    @Test(priority = 4, dependsOnMethods = {"quitWaitList"})
    public void deleteExistingWaitList()
    {
        logger.info("Entering - Delete WaitList");
        loginPage.loginByUserPassword(waitListProp.getProperty("CONF_USERNAME"), waitListProp.getProperty("CONF_PASSWORD"));
        waitlistPage.deleteWaitList(waitListProp.getProperty("CONF_WAITLIST_NAME"));
    }

    @AfterMethod
    public void logout() {
        logger.info("Entering - LogOut");
        //Uncomment the below line once a method is added to verify that the driver has joined waitlist
        loginPage.logout();
    }

}

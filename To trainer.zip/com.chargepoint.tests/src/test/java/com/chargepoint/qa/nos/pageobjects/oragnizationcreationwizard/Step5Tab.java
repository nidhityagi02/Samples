/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.oragnizationcreationwizard;

import com.chargepoint.qa.base.CPPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by Nidhi on 13-05-2015.
 */
public class Step5Tab extends CPPage {

    final WebDriver driver;

    @FindBy(how = How.ID, using = "agree")
    public WebElement   I_AGREE;
    @FindBy(how = How.CSS, using = "input[value='Continue to Step 6 >>']")
    private WebElement CONTINUE_TO_NEXT_STEP;


    public Step5Tab(WebDriver dr){
        this.driver = dr;
    }



public void Agree_Terms(){

    I_AGREE.click();
CONTINUE_TO_NEXT_STEP.click();
}

}

/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.managestations;

import com.chargepoint.qa.base.CPPage;
import com.chargepoint.qa.base.CPTest;
import com.chargepoint.qa.nos.pageobjects.home.HomePage;
import com.chargepoint.qa.nos.tests.datacreationflow.DataCreationFlow;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

/**
 * Created by Nidhi on 12-06-2015.
 */
public class ManageStation extends CPPage {

    final WebDriver driver;

    @FindBy(how = How.CSS, using = "div.subnav>ul>li:nth-child(2)>a")
    private WebElement PRICING_RESERVATION;

    @FindBy(how = How.CSS, using = "div#action_columns_right>a")
    private   WebElement CREATE_PRICING_RULE;

    @FindBy(how = How.CSS, using = "#pricingRuleName")
    private   WebElement PRICING_RULE_NAME;

    @FindBy(how = How.CSS, using = "#pricingRuleDescription")
    private   WebElement DESCRIPTION;

    @FindBy(how = How.CSS, using = "#mainPricePerSession")
    private   WebElement FLAT_FEE;

    @FindBy(how = How.CSS, using = "div.modulenav>ul>li:nth-child(4)>a")
    private   WebElement PRICING_POLICIES;


    @FindBy(how = How.CSS, using = "div#action_columns_right>a")
    private   WebElement CREATE_PRICING_POLICY;

    @FindBy(how = How.CSS, using = "div.newRuleContainer>div>input#pricingMasterSpecName")
    private   WebElement POLICY_NAME;


    @FindBy(how = How.CSS, using = "span#select2-chosen-10")
    private   WebElement DRIVER_GROUP;


    @FindBy(how = How.CSS, using = "div#select2-result-label-15")
    private   WebElement ALL_DRIVER;

    @FindBy(how = How.NAME, using = "specPricingRule")
    private   WebElement PRICING_RULE;

    @FindBy(how = How.CSS, using = "#form>div>div#newPricingRuleControls>button.applyAction")
    private   WebElement SAVE_BUTTON;


    @FindBy(how = How.CSS, using = "div#newPricingRuleControls>button.applyAction")
    private   WebElement SAVE_BUTTON_PRICING_POLICY;






    public  ManageStation(WebDriver dr) {

        this.driver = dr;

    }

    public void CreatePolicy() throws InterruptedException {


//    new HomePage(driver).clickManageStationsnTab();
        waitForElementtoPresent(driver, PRICING_RESERVATION, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
        PRICING_RESERVATION.click();
//        waitForElementtoPresent(driver, PRICING_RULE, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
        waitForElementtoPresent(driver, CREATE_PRICING_RULE, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
        CREATE_PRICING_RULE.click();
        waitForElementtoPresent(driver, PRICING_RULE_NAME, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));

        PRICING_RULE_NAME.sendKeys(uniquify("pri"));
        DESCRIPTION.sendKeys(uniquify("desc"));

FLAT_FEE.sendKeys(DataCreationFlow.datacreationProp.getProperty("FLATFEE"));

        SAVE_BUTTON.click();
        Thread.sleep(4000);
waitForElementtoPresent(driver, PRICING_POLICIES, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
PRICING_POLICIES.click();
        Thread.sleep(4000);
        waitForElementtoPresent(driver, CREATE_PRICING_POLICY, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
        CREATE_PRICING_POLICY.click();

//        for (String winHandle : driver.getWindowHandles()) {
//            driver.switchTo().window(winHandle); // switch focus of WebDriver to the next found window handle (that's your newly opened window)
//        }
        waitForElementtoPresent(driver, POLICY_NAME, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
            POLICY_NAME.sendKeys(uniquify("pn"));
        DRIVER_GROUP.click();
        waitForElementtoPresent(driver, ALL_DRIVER, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
        ALL_DRIVER.click();
        select(driver, PRICING_RULE, "Free");
        SAVE_BUTTON_PRICING_POLICY.click();
        Thread.sleep(5000);

    }

}

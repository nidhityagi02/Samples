/**
 * @author Nidhi
 */
package com.chargepoint.qa.nos.pageobjects.oragnizationcreationwizard;

import com.chargepoint.qa.base.CPPage;
import com.chargepoint.qa.base.CPTest;
import com.chargepoint.qa.nos.tests.datacreationflow.DataCreationFlow;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import java.util.Properties;

/**
 * Created by Nidhi on 13-05-2015.
 */
public class Step1Tab extends CPPage {

public String NetworkManager;

    final WebDriver driver;

    @FindBy(how = How.ID, using = "user_name")
    private WebElement USERNAME;

    @FindBy(how = How.ID, using = "password")
    private WebElement PASSWORD;

    @FindBy(how = How.ID, using = "confirm_password")
    private WebElement CONFIRM_PASSWORD;

    @FindBy(how = How.ID, using = "select_security_question")
    private WebElement SECUIRTY_QUESTION;

    @FindBy(how = How.ID, using = "securityAnswer")
    private WebElement SECUIRTY_ANSWER;



    @FindBy(how = How.ID, using = "btn_login_next")
    public WebElement CONTINUE_TO_NEXT_STEP;




    public Step1Tab(WebDriver dr){

            this.driver = dr;

    }


    public void enterStep1details(){

//        waitForElementtoPresent(driver,PASSWORD,30);





        for(String winHandle : driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
        }

        waitForElementtoPresent(driver, PASSWORD, Integer.parseInt(CPTest.prop.getProperty("CONF_WAIT_TIME")));
        USERNAME.clear();
        NetworkManager = uniquify("user");
        USERNAME.sendKeys(NetworkManager);
        PASSWORD.sendKeys(DataCreationFlow.datacreationProp.getProperty("PASSWORD"));
        CONFIRM_PASSWORD.sendKeys(DataCreationFlow.datacreationProp.getProperty("PASSWORD"));
        select(driver,SECUIRTY_QUESTION, "What is your favorite movie?");
        SECUIRTY_ANSWER.sendKeys(DataCreationFlow.datacreationProp.getProperty("SECUIRTY_ANSWER"));
        CONTINUE_TO_NEXT_STEP.click();
    }


public String getMangerName(){
    return  this.NetworkManager;
}

}


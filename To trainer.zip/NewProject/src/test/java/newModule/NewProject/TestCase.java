package newModule.NewProject;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

public class TestCase {
	@Test
	public void TC01() throws InterruptedException
	{
//		System.setProperty("webdriver.chrome.driver", "resources/chromedriver.exe");
	//	WebDriver driver = new ChromeDriver();
		File file = new File("C:\\Users\\intel\\Desktop\\IEDriverServer_x64_3.14.0\\IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		WebDriver driver = new InternetExplorerDriver();
		driver.get("https://www.google.com/");
		synchronized (driver)
		{
		    driver.wait(1000);
		}
		driver.findElement(By.name("q")).sendKeys("Testing");
		driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
	}
}

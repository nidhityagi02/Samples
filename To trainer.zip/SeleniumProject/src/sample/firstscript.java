package sample;

class firstscript {
	
	

}

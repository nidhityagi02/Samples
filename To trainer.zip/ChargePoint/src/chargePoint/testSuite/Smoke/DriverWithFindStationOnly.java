package chargePoint.testSuite.Smoke;

import org.testng.annotations.Test;

import chargePoint.baseClass.BaseClass;
import chargePoint.utils.AssertionOperations;
import chargePoint.utils.BusinessOperations;
import chargePoint.utils.ElementOperations;
import chargePoint.utils.FileOperations;

public class DriverWithFindStationOnly extends BaseClass {
	@Test
	public void testVerifySignUp(){
		
//		Step 1 - Click on Sign Up button on Homepage
		ElementOperations.Click("buttonSignUp_id");
		String titleText = ElementOperations.GetText("labelPageTitle_id");
		AssertionOperations.verifyStringsEquality(titleText, "Join Charge212Point");
		
//		Step 2 - Click on Terms and Conditions link at bottom of page
		ElementOperations.Swipe(400, 600, 400, 100, 1000);
		ElementOperations.Click("linkTermandCondition_xpath");
		// There is known issue with appium right now for chromedriver
		ElementOperations.ExplicitWait();
		ElementOperations.SwitchContext("WEBVIEW_com.android.browser");
		String text1 = ElementOperations.GetText("labelAddressSection_xpath");
		System.out.println(text1);
		String text2 = FileOperations.getValueFromDataPropertyFile("address");
		AssertionOperations.verifyStringsPartialEquality(text1, text2);
		String email = ElementOperations.GetText("labelEmail_xpath");
		AssertionOperations.verifyStringsEquality(email, FileOperations.getValueFromDataPropertyFile("termsemail"));
		String website = ElementOperations.GetText("labelAddressSection_xpath");
		AssertionOperations.verifyStringsEquality(website, FileOperations.getValueFromDataPropertyFile("website"));
		
//		Step 3 - Click on back button and then clicking on privacy policy link	
		ElementOperations.SwitchContext("NATIVE_APP");
		ElementOperations.Click("buttonBack_id");
//		ElementOperations.Click("linkPrivacyPolicy_xpath");
//		String privacyTitleText = ElementOperations.GetText("labelPageTitle_id");
//		AssertionOperations.verifyStringsEquality(privacyTitleText, "Privacy Policy");
//		
////		Step 4 - Click back and fill and submit form
//		ElementOperations.Click("buttonBack_id");	
//		ElementOperations.Swipe(400, 200, 400, 600, 1000);
//		ElementOperations.TypeText("editEmail_id", FileOperations.getValueFromDataPropertyFile("email"));
//		ElementOperations.Click("checkboxEmail_id");
//		ElementOperations.Click("checkboxEmail_id");
//		ElementOperations.TypeText("editPassword_id", FileOperations.getValueFromDataPropertyFile("password"));
//		ElementOperations.TypeText("editVerifyPassword_id", FileOperations.getValueFromDataPropertyFile("password"));
//		ElementOperations.Click("arrowEvatorRight_id");
//		ElementOperations.TypeText("editEvatorName_id", Integer.toString(BusinessOperations.generateRandomNumber()));
//		ElementOperations.Swipe(400, 600, 400, 100, 1000);
//		ElementOperations.TypeText("editPostalCode_id", FileOperations.getValueFromDataPropertyFile("postcode"));
//		ElementOperations.Click("checkboxTerms_id");
//		ElementOperations.Click("buttonSubmit_id");
//		AssertionOperations.verifyElementDisplayed("imageEvator_id");
//		AssertionOperations.verifyElementDisplayed("buttonCompleteProfile_xpath");
//		AssertionOperations.verifyElementDisplayed("buttonGotoMap_id");
//		
////		Step 5 - Click on GotoMap button
//		ElementOperations.Click("buttonGotoMap_id");
//		AssertionOperations.verifyElementDisplayed("buttonDoItLater_id");
//		AssertionOperations.verifyElementDisplayed("buttonAddInfo_id");
//		
////		Step 6 - Click on Do It Later button
//		ElementOperations.Click("buttonDoItLater_id");
//		ElementOperations.Click("buttonInfoNoLocation_xpath");
//		AssertionOperations.verifyElementDisplayed("promptPush_xpath");
//		
////		Step 7 - Press Yes Button 
//		ElementOperations.Click("buttonPushYes_xpath");
//		//AssertionOperations.verifyElementNotDisplayed("promptPush_xpath");
//		ElementOperations.Click("buttonMenuIcon_id");
//		ElementOperations.Click("menuOptionSettings_id");
//		ElementOperations.Click("menuOptionNotifications_id");
//		//ElementOperations.Click("checkboxPushFirst_xpath");
//		
////		Step 8 - Click on Back button
//		ElementOperations.Click("buttonNotificationBack_id");
//		ElementOperations.Click("buttonSettingsBack_id");
//		AssertionOperations.verifyElementDisplayed("buttonMenuIcon_id");
//		AssertionOperations.verifyElementDisplayed("screenMaps_id");
//		
////		Step 13 - Select other network filters and deselect chargepoint
//		ElementOperations.Click("buttonFilters_id");
//		ElementOperations.Click("labelNetworkFilterOption_id");
//		ElementOperations.Click("checkboxPowerChargepointFilter_id");
//		ElementOperations.Click("labelNetworkFIlterClose_id");
//		AssertionOperations.verifyElementProperty("checkboxAvailableFilter_id", "checked", "false");
//		AssertionOperations.verifyElementProperty("checkboxOccupiedFilter_id", "checked", "false");
//		AssertionOperations.verifyElementProperty("checkboxUnknownFilter_id", "checked", "false");
//		
////		Step 14 - Try to deselect all plug filter and verify error message
//		ElementOperations.Click("optionPlugFilter_id");
//		ElementOperations.Click("checkboxPlugLevel1Filter_id");
//		ElementOperations.Click("checkboxPlugLevel2Filter_id");
//		ElementOperations.Click("checkboxPlugChademoFilter_id");
//		ElementOperations.Click("checkboxPlugComboFilter_id");
//		ElementOperations.Click("checkboxPlugTeslaFilter_id");
//		AssertionOperations.verifyElementProperty("checkboxPlugTeslaFilter_id", "checked", "true");	
//		ElementOperations.Click("buttonPlugCloseFilter_id");
//		ElementOperations.Click("buttonFilters_id");
	}
}

package chargePoint.baseClass;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import chargePoint.utils.FileOperations;

public class BaseClass {

	private static AppiumDriver driver = null;
	public static String elementPropertiesFileName = null;
	
	@BeforeSuite
	public static void setUp(){
		Reporter.log("entering method setUp");
		elementPropertiesFileName = FileOperations.getValueFromPropertyFile("PLATFORM_NAME");
		initialize();
		launchApplication();
		Reporter.log("existing method setUp");
	}
	
	
	@AfterSuite
	public void tearDown(){
		Reporter.log("entering method tearDown");
//		driver.quit();
		Reporter.log("existing method tearDown");
	}
	
	
	public static void initialize(){
		Reporter.log("entering method initialize");
		setDriver(FileOperations.getValueFromPropertyFile("PLATFORM_NAME"));
		Reporter.log("existing method initialize");
	}
	
	
	public static void launchApplication() {
		Reporter.log("entering method launchApplication");
		getDriver().manage().timeouts().implicitlyWait(Integer.parseInt(FileOperations.getValueFromPropertyFile("implicitTimeout")), TimeUnit.SECONDS);
		Reporter.log("existing method launchApplication");
	}
	
	
	public static void setDriver(String platformName) {
		Reporter.log("entering method setDriver");
		if(platformName.equalsIgnoreCase("android")){	
			DesiredCapabilities capabilities = new DesiredCapabilities();
			
			capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, FileOperations.getValueFromPropertyFile("PLATFORM_NAME"));
			capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, FileOperations.getValueFromPropertyFile("PLATFORM_VERSION"));
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, FileOperations.getValueFromPropertyFile("DEVICE_NAME"));
			capabilities.setCapability(MobileCapabilityType.APP, FileOperations.getValueFromPropertyFile("APP"));
			capabilities.setCapability(MobileCapabilityType.APP_PACKAGE, FileOperations.getValueFromPropertyFile("APP_PACKAGE"));
			capabilities.setCapability(MobileCapabilityType.APP_ACTIVITY, FileOperations.getValueFromPropertyFile("APP_ACTIVITY"));
			
			try {
				driver = new AndroidDriver(new URL(FileOperations.getValueFromPropertyFile("url")), capabilities);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}else if(platformName.equalsIgnoreCase("ios")){
			DesiredCapabilities capabilities = new DesiredCapabilities();
			
			capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, FileOperations.getValueFromPropertyFile("PLATFORM_NAME"));
			capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, FileOperations.getValueFromPropertyFile("PLATFORM_VERSION"));
			capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, FileOperations.getValueFromPropertyFile("DEVICE_NAME"));
			capabilities.setCapability(MobileCapabilityType.APP, FileOperations.getValueFromPropertyFile("APP"));
			capabilities.setCapability(MobileCapabilityType.APP_PACKAGE, FileOperations.getValueFromPropertyFile("APP_PACKAGE"));
			capabilities.setCapability(MobileCapabilityType.APP_ACTIVITY, FileOperations.getValueFromPropertyFile("APP_ACTIVITY"));	
			
			try {
				driver = new AndroidDriver(new URL(FileOperations.getValueFromPropertyFile("url")), capabilities);
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
		Reporter.log("exiting method setDriver");
	}
	
	public static AppiumDriver getDriver() {
		return driver;
	}
}

package chargePoint.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.testng.Reporter;

import chargePoint.baseClass.BaseClass;

public class FileOperations {
	
	
	public static String getValueFromPropertyFile(String key) {
		Reporter.log("entering method getValueFromPropertyFile");
		String keyValue = null;
		Properties prop = new Properties();
		try{
			prop.load(new FileInputStream("src/config/configSettings.properties"));	
			keyValue = prop.getProperty(key);
		}catch (IOException e) {
			e.printStackTrace();
		}			
		Reporter.log("exiting method getValueFromPropertyFile");
		return keyValue;
	}	
	
	
	public static String getElementFromPropertyFile(String key) {
		Reporter.log("entering  method getElementFromPropertyFile");
		String fileName = null;
		
		if (BaseClass.elementPropertiesFileName.equals("Android")){
			fileName = "androidWebElements";
		} else {
			fileName = "iOSWebElements";
		}
		
		String keyValue = null;
		Properties prop = new Properties();
		try{
			prop.load(new FileInputStream("src/elementRepository/" + fileName + ".properties"));	
			keyValue = prop.getProperty(key);
		}catch (IOException e) {
			e.printStackTrace();
		}	
		Reporter.log("existing method getElementFromPropertyFile");
		return keyValue;
	}
	
	
	public static String getValueFromDataPropertyFile(String key) {
		Reporter.log("entering method getValueFromDataPropertyFile");
		String keyValue = null;
		Properties prop = new Properties();
		try{
			prop.load(new FileInputStream("src/data/data.properties"));	
			keyValue = prop.getProperty(key);
		}catch (IOException e) {
			e.printStackTrace();
		}			
		Reporter.log("exiting method getValueFromDataPropertyFile");
		return keyValue;
	}

}

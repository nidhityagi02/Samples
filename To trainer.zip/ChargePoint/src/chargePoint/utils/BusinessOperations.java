package chargePoint.utils;

import org.testng.Reporter;

public class BusinessOperations {
	
	public static void main (String [] args){
		System.out.println(generateRandomEmail());
	}
	
	public static String generateRandomEmail() {
		Reporter.log("entering method generateRandomEmail");
		String initialEmail = "chargepoint";
		String endEmail = "@aol.com";
		int midEmail = (int) (Math.random()*10000);
		String finalEmail = initialEmail + midEmail + endEmail;
		Reporter.log("exiting method generateRandomEmail");
		return finalEmail;
	}	
	
	
	public static int generateRandomNumber() {
		Reporter.log("entering method generateRandomNumber");
		int randomNumber = (int) (Math.random()*100000000);
		Reporter.log("exiting method generateRandomNumber");
		return randomNumber;
	}

}

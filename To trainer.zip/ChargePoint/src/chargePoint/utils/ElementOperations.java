package chargePoint.utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;

import io.appium.java_client.MobileBy;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import chargePoint.baseClass.BaseClass;


public class ElementOperations extends BaseClass {
	
	public static WebElement getElement(String elementName) {
		Reporter.log("entering method getElement");
		
		String initialIdStringValue = null;
		String locatorValue = null;
		String [] locatorType = null;
		WebElement element=null;
		
		locatorValue = FileOperations.getElementFromPropertyFile(elementName);
		locatorType = elementName.split("_");		
		
		if (locatorType[1].toLowerCase().equals("id")){
			try{
				Reporter.log("Searching locator using its ID");
				initialIdStringValue = FileOperations.getElementFromPropertyFile("initialIdString");
				element = getDriver().findElement(MobileBy.id(initialIdStringValue + locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}			
		} else if (locatorType[1].toLowerCase().equals("name")){
			try{
				Reporter.log("Searching locator using its Name");
				element = getDriver().findElement(MobileBy.name(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}	
		} else if (locatorType[1].toLowerCase().equals("AccessibilityId")){
			try{
				Reporter.log("Searching locator using its AccessibilityId");
				element = getDriver().findElement(MobileBy.AccessibilityId(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("AndroidUIAutomator")){
			try{
				Reporter.log("Searching locator using its AndroidUIAutomator");
				element = getDriver().findElement(MobileBy.AndroidUIAutomator(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("IosUIAutomation")){
			try{
				Reporter.log("Searching locator using its IosUIAutomation");
				element = getDriver().findElement(MobileBy.IosUIAutomation(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("className")){
			try{
				Reporter.log("Searching locator using its className");
				element = getDriver().findElement(MobileBy.className(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("cssSelector")){
			try{
				Reporter.log("Searching locator using its cssSelector");
				element = getDriver().findElement(MobileBy.cssSelector(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("linkText")){
			try{
				Reporter.log("Searching locator using its linkText");
				element = getDriver().findElement(MobileBy.linkText(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("partialLinkText")){
			try{
				Reporter.log("Searching locator using its partialLinkText");
				element = getDriver().findElement(MobileBy.partialLinkText(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("tagName")){
			try{
				Reporter.log("Searching locator using its tagName");
				element = getDriver().findElement(MobileBy.tagName(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("xpath")){
			try{
				Reporter.log("Searching locator using its xpath");
				element = getDriver().findElement(MobileBy.xpath(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else{
			Reporter.log("Locator Type [" +locatorType[1] +"] is not correct for element +[" +elementName +"]");
			element=null;
		}
		Reporter.log("exiting method getElement");
		return element;
	}
	
		
	public static List<WebElement> getElements(String elementName) {
		Reporter.log("entering method getElements");
		
		String initialIdStringValue = null;
		String locatorValue = null;
		String [] locatorType = null;
		List<WebElement> element = null;
		
		locatorValue = FileOperations.getElementFromPropertyFile(elementName);
		locatorType = elementName.split("_");		
		
		if (locatorType[1].toLowerCase().equals("id")){
			try{
				Reporter.log("Searching locator using its ID");
				initialIdStringValue = FileOperations.getElementFromPropertyFile("initialIdString");
				element = getDriver().findElements(MobileBy.id(initialIdStringValue + locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}			
		} else if (locatorType[1].toLowerCase().equals("name")){
			try{
				Reporter.log("Searching locator using its Name");
				element = getDriver().findElements(MobileBy.name(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}	
		} else if (locatorType[1].toLowerCase().equals("AccessibilityId")){
			try{
				Reporter.log("Searching locator using its AccessibilityId");
				element = getDriver().findElements(MobileBy.AccessibilityId(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("AndroidUIAutomator")){
			try{
				Reporter.log("Searching locator using its AndroidUIAutomator");
				element = getDriver().findElements(MobileBy.AndroidUIAutomator(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("IosUIAutomation")){
			try{
				Reporter.log("Searching locator using its IosUIAutomation");
				element = getDriver().findElements(MobileBy.IosUIAutomation(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("className")){
			try{
				Reporter.log("Searching locator using its className");
				element = getDriver().findElements(MobileBy.className(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("cssSelector")){
			try{
				Reporter.log("Searching locator using its cssSelector");
				element = getDriver().findElements(MobileBy.cssSelector(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("linkText")){
			try{
				Reporter.log("Searching locator using its linkText");
				element = getDriver().findElements(MobileBy.linkText(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("partialLinkText")){
			try{
				Reporter.log("Searching locator using its partialLinkText");
				element = getDriver().findElements(MobileBy.partialLinkText(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("tagName")){
			try{
				Reporter.log("Searching locator using its tagName");
				element = getDriver().findElements(MobileBy.tagName(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else if (locatorType[1].toLowerCase().equals("xpath")){
			try{
				Reporter.log("Searching locator using its xpath");
				element = getDriver().findElements(MobileBy.xpath(locatorValue));
				System.out.println("Element [" + elementName +"] is found.");
			} catch (Exception e){
				GetScreenshot(elementName);
				Reporter.log("Can not find element [" +elementName +"]. Check the locator values ");
				return null;
			}
		} else{
			Reporter.log("Locator Type [" +locatorType[1] +"] is not correct for element +[" +elementName +"]");
			element=null;
		}
		Reporter.log("exiting method getElement");
		return element;
	}
	
	
	public static void Click(String elementName)
	{
		Reporter.log("entering method Click");
		WebElement element = getElement(elementName);
		if(!(element==null))
		{
			System.out.println("element is not null");
			element.click();
			Reporter.log("Clicked on element [" + elementName +"]");
		}else{
			GetScreenshot(elementName);
			System.out.println("element is null");
		}	
		Reporter.log("exiting method Click");
	}
	
	
	public static void Swipe(int startx, int starty, int endx, int endy, int timeout)
	{
		Reporter.log("entering method Swipe");
		getDriver().swipe(startx, starty, endx, endy, timeout);
		Reporter.log("exiting method Swipe");
	}
	
	
	public static String GetText(String elementName)
	{
		Reporter.log("entering method GetText");
		String text ="";
		WebElement element = getElement(elementName);
		if(!(element==null))
		{
			System.out.println("element is not null");
			text =	element.getText();
			Reporter.log("Text of Element [" + elementName +"] is " + text);
		}else{
			GetScreenshot(elementName);
			System.out.println("element is null");
		}
		Reporter.log("exiting method GetText");
		return text ;		
	}
	
	
	public static void TypeText(String strElementLogicalName, String value)
	{
		Reporter.log("entering method TypeText");
		WebElement element = getElement(strElementLogicalName);
		if(!(element==null))
		{
			element.clear();
			element.sendKeys(value);
		}
		if(value.isEmpty())
			System.out.println("Setting the element value with blank string");
		Reporter.log("Setting the object value with blank string");
		Reporter.log("exiting method TypeText");
	}
	
	
	public static void GetScreenshot(String name)
	{
		Reporter.log("entering method GetScreenshot");
		
		Date currDate = new Date();
	    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
	    String dateAndTime = dateFormat.format(currDate);
	    System.out.println(dateAndTime);

		File scrFile = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(scrFile, new File("screenShots/" + name + "_" + dateAndTime +".png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		Reporter.log("exiting method GetScreenshot");
	}
	
	
	public static void SwitchContext (String conext){
		Reporter.log("entering method ContextSwitch");
		Set<String> contextNames = getDriver().getContextHandles();
        for (String contextName : contextNames) {
            System.out.println(contextName);
            if (contextName.contains(conext)){
            	getDriver().context(contextName);
            }
         }
        Reporter.log("exiting method ContextSwitch");
	}
	
	
	public static void ExplicitWait(){
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}

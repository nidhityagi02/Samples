package chargePoint.utils;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Reporter;

public class AssertionOperations {
	
	public static void verifyElementDisplayed(String strElementLogicalName)
	{
		Reporter.log("entering method verifyElementDisplayed");
		
		try{
			
			WebElement objWebElement = ElementOperations.getElement(strElementLogicalName);
			boolean bStatus=objWebElement.isDisplayed();
			Assert.assertTrue(bStatus);
			Reporter.log("element [" + strElementLogicalName +"] is displayed");	
			
		} catch (Exception e){
			
			ElementOperations.GetScreenshot(strElementLogicalName);
			Reporter.log("element [" + strElementLogicalName +"] is not displayed");
			
		}
		
		Reporter.log("exiting method verifyElementNotDisplayed");
	}
	
	
	public static void verifyElementNotDisplayed(String strElementLogicalName)
	{
		Reporter.log("entering method verifyElementNotDisplayed");
		
		try{
			
			WebElement objWebElement = ElementOperations.getElement(strElementLogicalName);
			boolean bStatus=objWebElement.isDisplayed();
			Assert.assertFalse(bStatus);
			Reporter.log("element [" + strElementLogicalName +"] is not displayed");	
			
		} catch (Exception e){
			
			ElementOperations.GetScreenshot(strElementLogicalName);
			Reporter.log("element [" + strElementLogicalName +"] is displayed");
			
		}
		
		Reporter.log("exiting method verifyElementNotDisplayed");

	}
	
	
	public static void verifyElementEnabled(String strElementLogicalName)
	{
		Reporter.log("entering method verifyElementEnabled");
		
		try{
			
			WebElement objWebElement = ElementOperations.getElement(strElementLogicalName);
			boolean bStatus=objWebElement.isEnabled();
			Assert.assertTrue(bStatus);
			Reporter.log("element [" + strElementLogicalName +"] is Enabled");	
			
		} catch (Exception e){
			
			ElementOperations.GetScreenshot(strElementLogicalName);
			Reporter.log("element [" + strElementLogicalName +"] is not Enabled");
			
		}

		Reporter.log("exiting method verifyElementEnabled");

	}
	
	
	public static void verifyElementNotEnabled(String strElementLogicalName)
	{
		Reporter.log("entering method verifyElementNotEnabled");
		
		try{
			
			WebElement objWebElement = ElementOperations.getElement(strElementLogicalName);
			boolean bStatus=objWebElement.isEnabled();
			Assert.assertFalse(bStatus);
			Reporter.log("element [" + strElementLogicalName +"] is not Enabled");	
			
		} catch (Exception e){
			
			ElementOperations.GetScreenshot(strElementLogicalName);
			Reporter.log("element [" + strElementLogicalName +"] is Enabled");
			
		}
		
		Reporter.log("exiting method verifyElementNotEnabled");

	}
	
	
	public static void verifyStringsEquality(String actualStr, String ExpectedStr)
	{
		Reporter.log("entering method verifyStringsEquality");
		try{
			Assert.assertEquals(actualStr, ExpectedStr);
			Reporter.log("String " + actualStr + " is equal to String " + ExpectedStr);
		} catch (AssertionError e){
			ElementOperations.GetScreenshot("label");
			Reporter.log("String " + actualStr + " is not equal to String " + ExpectedStr);
		}
		
		Reporter.log("exiting method verifyStringsEquality");
	}
	
	
	public static void verifyStringsPartialEquality(String text1, String text2)
	{
		Reporter.log("entering method verifyStringsPartialEquality");
		try{
			Assert.assertTrue(text1.contains(text2));
			Reporter.log("String " + text2 + " is found in String " + text1);
		} catch (AssertionError e){
			ElementOperations.GetScreenshot("label");
			Reporter.log("String " + text2 + " is not found in String " + text1);
		}
		
		Reporter.log("exiting method verifyStringsPartialEquality");
	}
	
	
	public static void verifyElementProperty(String strElementLogicalName, String property, String expectedval)
	{
		Reporter.log("entering method verifyElementProperty");
		String val = null;
		try{
			
			WebElement objWebElement = ElementOperations.getElement(strElementLogicalName);
			val=objWebElement.getAttribute(property);
			Assert.assertEquals(val, expectedval);
			Reporter.log("element [" + strElementLogicalName +"] " + property + " expected value " + expectedval + "is equal to actual value " + val);	
			
		} catch (Exception e){
			
			ElementOperations.GetScreenshot(strElementLogicalName);
			Reporter.log("element [" + strElementLogicalName +"] " + property + " expected value " + expectedval + "is not equal to actual value " + val);
			
		}
		
		Reporter.log("exiting method verifyElementProperty");
	}
	

}

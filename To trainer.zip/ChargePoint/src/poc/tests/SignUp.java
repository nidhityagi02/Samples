package poc.tests;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import java.awt.Dialog.ModalityType;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class SignUp {
	private static AppiumDriver driver;
	
	@Test

	public <DesiredCapabilities> void Testcase01() throws MalformedURLException, InterruptedException {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(ModalityType.PLATFORM_NAME, "Android");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "5.0");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability(MobileCapabilityType.APP,"E:\\Apks\\ChargePointAndroid-qamaint-release.apk");
        capabilities.setCapability(MobileCapabilityType.APP_PACKAGE, "com.chargepoint.qamaint");
		capabilities.setCapability(MobileCapabilityType.APP_ACTIVITY,"com.chargepoint.activity.launcher.LauncherActivity");	
		
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);		

		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/Button_sign_up")).click();
		String title = driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/page_title")).getText();
		System.out.println(title);
		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/email")).sendKeys("chargepnt1225@aol.com");
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/email_login_check")).click();
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/email_login_check")).click();
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/password")).sendKeys("charge123");
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/verify_password")).sendKeys("charge123");		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/arrow_right")).click();
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/evatar_name")).sendKeys("Chargeevatar1225");
		
		driver.swipe(400, 600, 400, 100, 1000);
		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/postalCode")).sendKeys("12345");
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/term_checkbox")).click();
						
		String copyrightText = driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/copyright")).getText();
		System.out.println(copyrightText);

		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/submit")).click();
		Thread.sleep(7000);
		
		String welcomeTitle = driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/page_title")).getText();
		System.out.println(welcomeTitle);
		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/goto_map")).click();
		Thread.sleep(3000);
//		Alert alert = driver.switchTo().alert();
//		alert.accept();
		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/btnCancel")).click();
		Thread.sleep(3000);
//		Alert alert1 = driver.switchTo().alert();
//		alert1.accept();
		
		driver.quit();
		
		
//		driver.findElement(MobileBy.AndroidUIAutomator("text(\"Sign Up\")")).click();
//		driver.findElement(MobileBy.AccessibilityId("id")).click();
//		driver.findElementfindElement(By.xpath("//button[text()='Sign Up']")).click();
		}
	}

	
	
	
	
	
	
	
	/*
	
	public static void main(String [] args) throws MalformedURLException, InterruptedException {
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION, "5.0");
        capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, "Android Emulator");
        capabilities.setCapability(MobileCapabilityType.APP,"E:\\Apks\\ChargePointAndroid-qamaint-release.apk");
        capabilities.setCapability(MobileCapabilityType.APP_PACKAGE, "com.chargepoint.qamaint");
		capabilities.setCapability(MobileCapabilityType.APP_ACTIVITY,"com.chargepoint.activity.launcher.LauncherActivity");	
		
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);		

		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/Button_sign_up")).click();
		String title = driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/page_title")).getText();
		System.out.println(title);
		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/email")).sendKeys("chargepnt1225@aol.com");
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/email_login_check")).click();
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/email_login_check")).click();
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/password")).sendKeys("charge123");
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/verify_password")).sendKeys("charge123");		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/arrow_right")).click();
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/evatar_name")).sendKeys("Chargeevatar1225");
		
		driver.swipe(400, 600, 400, 100, 1000);
		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/postalCode")).sendKeys("12345");
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/term_checkbox")).click();
						
		String copyrightText = driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/copyright")).getText();
		System.out.println(copyrightText);

		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/submit")).click();
		Thread.sleep(7000);
		
		String welcomeTitle = driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/page_title")).getText();
		System.out.println(welcomeTitle);
		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/goto_map")).click();
		Thread.sleep(3000);
//		Alert alert = driver.switchTo().alert();
//		alert.accept();
		
		driver.findElement(MobileBy.id("com.chargepoint.qamaint:id/btnCancel")).click();
		Thread.sleep(3000);
//		Alert alert1 = driver.switchTo().alert();
//		alert1.accept();
		
		driver.quit();
		
		
//		driver.findElement(MobileBy.AndroidUIAutomator("text(\"Sign Up\")")).click();
//		driver.findElement(MobileBy.AccessibilityId("id")).click();
//		driver.findElementfindElement(By.xpath("//button[text()='Sign Up']")).click();
		}
	}
*/
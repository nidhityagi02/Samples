package objectRepository;

public class Test1 {

}

package sample.MyProject;

import org.testng.annotations.Test;

public class Test1 {
	@Test
	public void mytestcase01()
	{
		System.out.println("My first test case");
	}
}

/*
package chargePoint.testSuite.Smoke;

import org.testng.annotations.Test;

import chargePoint.baseClass.BaseClass;
import chargePoint.utils.AssertionOperations;
import chargePoint.utils.BusinessOperations;
import chargePoint.utils.ElementOperations;

public class VerifySignUp extends BaseClass {
	
	@Test
	public void testVerifySignUp(){
		ElementOperations.Click("buttonSignUp_id");
		String titleText = ElementOperations.GetText("labelPageTitle_id");
		AssertionOperations.verifyStringsEquality(titleText, "Join Charge212Point");
		ElementOperations.TypeText("editEmail_id", BusinessOperations.generateRandomEmail());
		ElementOperations.Click("checkboxEmail_id");
		ElementOperations.Click("checkboxEmail_id");
		ElementOperations.TypeText("editPassword_id", "chargepoint@123");
		ElementOperations.TypeText("editVerifyPassword_id", "chargepoint@123");
		ElementOperations.Click("arrowEvatorRight_id");
		ElementOperations.TypeText("editEvatorName_id", Integer.toString(BusinessOperations.generateRandomNumber()));
		ElementOperations.Swipe(400, 600, 400, 100, 1000);
		ElementOperations.TypeText("editPostalCode_id", Integer.toString(BusinessOperations.generateRandomNumber()));
		ElementOperations.Click("checkboxTerms_id");
		ElementOperations.Click("buttonSubmit_id");
	}

}
*/